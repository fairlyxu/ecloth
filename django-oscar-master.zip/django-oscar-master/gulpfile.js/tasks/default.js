var gulp = require('gulp');

gulp.task('default', ['less']);
