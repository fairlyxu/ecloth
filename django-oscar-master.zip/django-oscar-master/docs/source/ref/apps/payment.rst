=======
Payment
=======

The payment app contains models that capture how orders are paid for.  It does
not have any views.

Abstract models
---------------

.. automodule:: oscar.apps.payment.abstract_models
    :members:
