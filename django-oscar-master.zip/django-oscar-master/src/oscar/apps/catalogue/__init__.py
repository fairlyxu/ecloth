default_app_config = 'oscar.apps.catalogue.config.CatalogueConfig'
