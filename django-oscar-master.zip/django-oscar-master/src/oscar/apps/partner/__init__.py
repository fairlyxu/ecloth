default_app_config = 'oscar.apps.partner.config.PartnerConfig'
