default_app_config = 'oscar.apps.order.config.OrderConfig'
