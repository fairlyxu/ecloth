default_app_config = (
    'oscar.apps.dashboard.promotions.config.PromotionsDashboardConfig')
