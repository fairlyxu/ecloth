default_app_config = 'oscar.apps.dashboard.pages.config.PagesDashboardConfig'
