default_app_config = 'oscar.apps.checkout.config.CheckoutConfig'
