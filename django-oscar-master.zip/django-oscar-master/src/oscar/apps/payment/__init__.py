default_app_config = 'oscar.apps.payment.config.PaymentConfig'
