=====================
Contributing to Oscar
=====================

Thank you for wanting to contribute! You can find detailed guidance in the repository at ``docs/source/internals/contributing``, or online at:

https://django-oscar.readthedocs.io/en/latest/internals/contributing/index.html
